/**
 * Session-only health context.
 *
 * PRIVACY CONTRACT — the whole design rests on this:
 *   - lives in sessionStorage, cleared when the tab closes
 *   - sent with a request, used for that request, never written to the database
 *   - never logged, never cached
 *   - never included in an embedding call (see src/lib/embeddings.ts) — the
 *     embedding provider's free tier trains on submitted content
 *
 * Only supplements and explicitly-saved Decision Cards persist.
 */

export type Sex = 'female' | 'male';

export interface HealthContext {
  /** Exact age in years — drives NIH life-stage row selection. */
  ageYears: number | null;
  sex: Sex | null;
  pregnant: boolean;
  breastfeeding: boolean;
  conditions: string[];
  medications: string[];
}

export const EMPTY_CONTEXT: HealthContext = {
  ageYears: null,
  sex: null,
  pregnant: false,
  breastfeeding: false,
  conditions: [],
  medications: [],
};

/**
 * Conditions chosen because NIH ODS fact sheets actually discuss them in
 * relation to supplement safety. A longer list would collect more sensitive
 * data without producing better answers — minimum necessary, not maximum
 * possible.
 */
export const CONDITIONS = [
  'Kidney disease',
  'Liver disease',
  'Heart disease',
  'High blood pressure',
  'Diabetes',
  'Cancer (current or past treatment)',
  'Thyroid condition',
  'Osteoporosis or low bone density',
  'Anemia or low iron',
  'Digestive condition affecting absorption',
  'Autoimmune condition',
  'Bleeding or clotting disorder',
] as const;

/** Pregnancy/lactation only apply to some people; don't ask everyone. */
export function showsPregnancyOptions(ctx: HealthContext): boolean {
  return ctx.sex === 'female' && ctx.ageYears !== null && ctx.ageYears >= 10 && ctx.ageYears <= 60;
}

export function hasAnyContext(ctx: HealthContext): boolean {
  return (
    ctx.ageYears !== null ||
    ctx.sex !== null ||
    ctx.pregnant ||
    ctx.breastfeeding ||
    ctx.conditions.length > 0 ||
    ctx.medications.length > 0
  );
}

/** Short summary for the collapsed panel header. */
export function summarize(ctx: HealthContext): string {
  if (!hasAnyContext(ctx)) return 'Not set — answers will be general';
  const bits: string[] = [];
  if (ctx.ageYears !== null) bits.push(`${ctx.ageYears}`);
  if (ctx.sex) bits.push(ctx.sex);
  if (ctx.pregnant) bits.push('pregnant');
  if (ctx.breastfeeding) bits.push('breastfeeding');
  if (ctx.conditions.length) bits.push(`${ctx.conditions.length} condition${ctx.conditions.length > 1 ? 's' : ''}`);
  if (ctx.medications.length) bits.push(`${ctx.medications.length} medication${ctx.medications.length > 1 ? 's' : ''}`);
  return bits.join(' · ');
}

const KEY = 'clearlabel.health-context';

export function loadContext(): HealthContext {
  if (typeof window === 'undefined') return EMPTY_CONTEXT;
  try {
    const raw = window.sessionStorage.getItem(KEY);
    return raw ? { ...EMPTY_CONTEXT, ...JSON.parse(raw) } : EMPTY_CONTEXT;
  } catch {
    return EMPTY_CONTEXT;
  }
}

export function saveContext(ctx: HealthContext): void {
  if (typeof window === 'undefined') return;
  try {
    // sessionStorage, not localStorage: this should not outlive the tab.
    window.sessionStorage.setItem(KEY, JSON.stringify(ctx));
  } catch {
    /* private browsing or storage disabled — the app still works, just unremembered */
  }
}

export function clearContext(): void {
  if (typeof window === 'undefined') return;
  try {
    window.sessionStorage.removeItem(KEY);
  } catch {
    /* ignore */
  }
}

/** Reading level derived from age. Presentation only — never affects dosage logic. */
export function defaultReadingLevel(ageYears: number | null): 'teen' | 'adult' | 'senior' {
  if (ageYears === null) return 'adult';
  if (ageYears >= 13 && ageYears < 18) return 'teen';
  if (ageYears >= 65) return 'senior';
  return 'adult';
}
