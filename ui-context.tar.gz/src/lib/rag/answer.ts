import 'server-only';
import { z } from 'zod';
import { generateStructured } from '@/lib/llm';
import { retrieve, formatContext, toCitations, dedupeCitations, type DisplayCitation } from './retrieve';
import type { HealthContext } from '@/lib/health-context';
import { describePerson } from '@/lib/nih/life-stage';

export const AUDIENCES = ['teen', 'adult', 'senior'] as const;
export type Audience = (typeof AUDIENCES)[number];

const AUDIENCE_STYLE: Record<Audience, string> = {
  teen: 'A 14-17 year old. Grade 6-8 reading level. Short sentences, concrete examples, no condescension. Skip clinical jargon entirely.',
  adult: 'A general adult reader. Grade 8-10 reading level. Plain language, no jargon without a gloss.',
  senior:
    'An adult aged 65 or older. Grade 6-8 reading level. Larger conceptual chunks, one idea per sentence. Foreground medication interactions and kidney/liver considerations where the sources mention them.',
};

// The three-way split comes straight from the project problem statement:
// separate evidence from uncertainty from marketing.
export const AnswerSchema = z.object({
  evidence: z
    .string()
    .describe('What the NIH sources actually establish. Cite with [1], [2]. Empty string if the sources say nothing.'),
  uncertainty: z
    .string()
    .describe('What the sources describe as unclear, mixed, or under study. Empty string if not discussed.'),
  marketing: z
    .string()
    .describe(
      'Common marketing claims the sources do NOT support, only when the sources speak to them. Empty string otherwise.',
    ),
  forYou: z
    .string()
    .optional()
    .describe(
      'Only when the reader supplied age, sex, pregnancy status, conditions, or medications AND the sources address them. Begin "Based on the information you provided". Empty or omitted otherwise.',
    ),
  citationsUsed: z.array(z.number().int().positive()).describe('Context numbers actually cited above.'),
});

export type Answer = z.infer<typeof AnswerSchema>;

export interface AskResult {
  answer: Answer | null;
  /** Deduped for display; `chunkIds` keeps the full retrieval trace. */
  citations: DisplayCitation[];
  refused: boolean;
  refusalReason?: string;
  topSimilarity: number;
  chunkIds: string[];
}

const SYSTEM = `You answer questions about dietary supplements for the general public.

Absolute rules:
- Use ONLY the numbered context provided. It comes from NIH Office of Dietary Supplements fact sheets.
- Never add facts from your own knowledge, even if you are confident they are correct.
- Cite every factual sentence with the bracketed number of its source, like [2].
- If the context does not answer the question, leave the relevant field as an empty string. Do not speculate.
- Never give personal medical advice, dosing instructions for an individual, or a diagnosis.
- Do not tell anyone to start, stop, or change a supplement or medication. Refer them to a clinician.
- Write in the reader's language: if the question is in Spanish, answer in Spanish.

When the reader has supplied personal details, you may relate the sources to them in the
"forYou" field, under strict limits:
- Open with "Based on the information you provided" — never "based on your medical history".
- Report only what the NIH sources say about that age, sex, life stage, condition, or drug.
- If the sources do not address their situation, say so plainly: "NIH's fact sheets don't
  give specific guidance for this condition." Never fill the gap with a dosage adjustment,
  a reassurance, or an inference.
- Never state that something is safe or unsafe FOR THEM. Report what NIH documents and
  point them to a clinician.
- Leave "forYou" out entirely when they supplied nothing or the sources are silent.`;

export async function ask(
  question: string,
  {
    audience = 'adult',
    language = 'en',
    healthContext,
  }: { audience?: Audience; language?: 'en' | 'es'; healthContext?: HealthContext } = {},
): Promise<AskResult> {
  // More context when the reader has conditions or medications: interaction and
  // health-effect sections need to be in the retrieved set for the model to be
  // able to address them at all.
  const needsWiderNet =
    !!healthContext && (healthContext.conditions.length > 0 || healthContext.medications.length > 0);

  // NOTE: only `question` is embedded. Health context is NEVER part of a
  // retrieval query — see the guard in src/lib/embeddings.ts.
  const { chunks, topSimilarity, belowThreshold } = await retrieve(question, {
    language,
    matchCount: needsWiderNet ? 12 : 8,
  });

  if (belowThreshold) {
    return {
      answer: null,
      citations: [],
      refused: true,
      refusalReason:
        "The NIH Office of Dietary Supplements fact sheets don't cover this question. I only answer from those sources, so I don't have an answer for you here.",
      topSimilarity,
      chunkIds: [],
    };
  }

  const answer = await generateStructured(AnswerSchema, {
    system: SYSTEM,
    prompt: `Reader: ${AUDIENCE_STYLE[audience]}
${describeContext(healthContext)}
Question: ${question}

Context:
${formatContext(chunks)}

Return JSON with keys: evidence, uncertainty, marketing, forYou (optional), citationsUsed.`,
    temperature: 0.2,
    maxTokens: 2048,
  });

  return {
    answer,
    citations: dedupeCitations(toCitations(chunks), answer.citationsUsed),
    refused: false,
    topSimilarity,
    chunkIds: chunks.map((c) => c.chunk_id),
  };
}


/**
 * Render the session health context for the prompt.
 *
 * This text goes to the generation provider only. It must never be appended to a
 * retrieval query, because the embedding provider's free tier trains on
 * submitted content.
 */
function describeContext(ctx?: HealthContext): string {
  if (!ctx) return '';
  const lines: string[] = [];

  if (ctx.ageYears !== null) {
    lines.push(
      `The reader states: ${describePerson({
        ageYears: ctx.ageYears,
        sex: ctx.sex ?? undefined,
        pregnant: ctx.pregnant,
        breastfeeding: ctx.breastfeeding,
      })}.`,
    );
  } else if (ctx.sex || ctx.pregnant || ctx.breastfeeding) {
    const bits = [ctx.sex, ctx.pregnant && 'pregnant', ctx.breastfeeding && 'breastfeeding'].filter(Boolean);
    lines.push(`The reader states: ${bits.join(', ')}.`);
  }

  if (ctx.conditions.length) lines.push(`Reported conditions: ${ctx.conditions.join(', ')}.`);
  if (ctx.medications.length) lines.push(`Reported medications: ${ctx.medications.join(', ')}.`);

  if (!lines.length) return '';
  return `\n${lines.join(' ')}\nUse these only to surface what the NIH sources say about them. Do not infer anything the sources do not state.\n`;
}