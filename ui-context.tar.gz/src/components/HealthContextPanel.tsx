'use client';

import { useState } from 'react';
import {
  CONDITIONS,
  showsPregnancyOptions,
  summarize,
  hasAnyContext,
  type HealthContext,
  type Sex,
} from '@/lib/health-context';

export default function HealthContextPanel({
  value,
  onChange,
  onClear,
}: {
  value: HealthContext;
  onChange: (next: HealthContext) => void;
  onClear: () => void;
}) {
  const [open, setOpen] = useState(false);
  const [medDraft, setMedDraft] = useState('');
  const set = (patch: Partial<HealthContext>) => onChange({ ...value, ...patch });

  const addMed = () => {
    const name = medDraft.trim();
    if (!name || value.medications.includes(name)) return setMedDraft('');
    set({ medications: [...value.medications, name] });
    setMedDraft('');
  };

  return (
    <div className="mb-4 rounded-xl border border-slate-200">
      <button
        type="button"
        onClick={() => setOpen(!open)}
        aria-expanded={open}
        className="flex w-full items-center justify-between px-4 py-3 text-left"
      >
        <span>
          <span className="text-sm font-semibold text-slate-800">About you</span>
          <span className="ml-2 text-sm text-slate-500">{summarize(value)}</span>
        </span>
        <span className="text-slate-400">{open ? '−' : '+'}</span>
      </button>

      {open && (
        <div className="space-y-5 border-t border-slate-200 px-4 py-4">
          <p className="rounded-lg bg-teal-50 px-3 py-2 text-xs leading-relaxed text-teal-900">
            <span className="font-semibold">None of this is saved.</span> It stays in this
            browser tab, is used only for the answers you request, and disappears when you
            close the tab. We never write it to our database.
          </p>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label htmlFor="age" className="mb-1 block text-sm font-medium text-slate-700">
                Age
              </label>
              <input
                id="age"
                type="number"
                min={0}
                max={120}
                value={value.ageYears ?? ''}
                onChange={(e) => set({ ageYears: e.target.value === '' ? null : Number(e.target.value) })}
                placeholder="e.g. 34"
                className="w-full rounded-lg border border-slate-300 px-3 py-2 outline-none focus:border-teal-600 focus:ring-1 focus:ring-teal-600"
              />
              <p className="mt-1 text-xs text-slate-500">
                NIH intake limits change at 18, 50, 70 — exact age matters.
              </p>
            </div>

            <div>
              <span className="mb-1 block text-sm font-medium text-slate-700">Sex</span>
              <div className="flex gap-2">
                {(['female', 'male'] as Sex[]).map((s) => (
                  <button
                    key={s}
                    type="button"
                    onClick={() => set({ sex: value.sex === s ? null : s })}
                    className={`flex-1 rounded-lg px-3 py-2 text-sm capitalize transition ${
                      value.sex === s ? 'bg-teal-700 text-white' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                    }`}
                  >
                    {s}
                  </button>
                ))}
              </div>
              <p className="mt-1 text-xs text-slate-500">
                NIH publishes separate intake tables for each.
              </p>
            </div>
          </div>

          {showsPregnancyOptions(value) && (
            <fieldset>
              <legend className="mb-1 text-sm font-medium text-slate-700">
                Pregnancy or breastfeeding
              </legend>
              <div className="flex flex-wrap gap-2">
                {([
                  ['pregnant', 'Pregnant'],
                  ['breastfeeding', 'Breastfeeding'],
                ] as const).map(([key, label]) => (
                  <label
                    key={key}
                    className={`cursor-pointer rounded-full px-3.5 py-1.5 text-sm transition ${
                      value[key] ? 'bg-teal-700 text-white' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                    }`}
                  >
                    <input
                      type="checkbox"
                      className="sr-only"
                      checked={value[key]}
                      onChange={(e) => set({ [key]: e.target.checked } as Partial<HealthContext>)}
                    />
                    {label}
                  </label>
                ))}
              </div>
              <p className="mt-1 text-xs text-slate-500">
                NIH publishes distinct limits for pregnancy and lactation.
              </p>
            </fieldset>
          )}

          <fieldset>
            <legend className="mb-1 text-sm font-medium text-slate-700">
              Health conditions <span className="font-normal text-slate-500">(optional)</span>
            </legend>
            <div className="flex flex-wrap gap-2">
              {CONDITIONS.map((c) => {
                const on = value.conditions.includes(c);
                return (
                  <label
                    key={c}
                    className={`cursor-pointer rounded-full px-3 py-1.5 text-sm transition ${
                      on ? 'bg-teal-700 text-white' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                    }`}
                  >
                    <input
                      type="checkbox"
                      className="sr-only"
                      checked={on}
                      onChange={() =>
                        set({
                          conditions: on
                            ? value.conditions.filter((x) => x !== c)
                            : [...value.conditions, c],
                        })
                      }
                    />
                    {c}
                  </label>
                );
              })}
            </div>
          </fieldset>

          <div>
            <label htmlFor="med" className="mb-1 block text-sm font-medium text-slate-700">
              Medications <span className="font-normal text-slate-500">(optional)</span>
            </label>
            <div className="flex gap-2">
              <input
                id="med"
                value={medDraft}
                onChange={(e) => setMedDraft(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    addMed();
                  }
                }}
                placeholder="e.g. warfarin"
                className="flex-1 rounded-lg border border-slate-300 px-3 py-2 outline-none focus:border-teal-600 focus:ring-1 focus:ring-teal-600"
              />
              <button
                type="button"
                onClick={addMed}
                className="rounded-lg bg-slate-100 px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-200"
              >
                Add
              </button>
            </div>
            {value.medications.length > 0 && (
              <ul className="mt-2 flex flex-wrap gap-2">
                {value.medications.map((m) => (
                  <li
                    key={m}
                    className="flex items-center gap-1.5 rounded-full bg-slate-100 py-1 pr-1.5 pl-3 text-sm text-slate-700"
                  >
                    {m}
                    <button
                      type="button"
                      onClick={() => set({ medications: value.medications.filter((x) => x !== m) })}
                      aria-label={`Remove ${m}`}
                      className="rounded-full px-1.5 text-slate-400 hover:bg-slate-200 hover:text-slate-700"
                    >
                      ×
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </div>

          {hasAnyContext(value) && (
            <button
              type="button"
              onClick={onClear}
              className="text-sm font-medium text-slate-500 hover:text-red-700"
            >
              Clear everything
            </button>
          )}
        </div>
      )}
    </div>
  );
}
